/**
 * verify_release.js — Nextritech PFP Production Build Verifier
 * Run: node verify_release.js dist/formulation_app_PROD.html
 */
const fs = require('fs');
const path = require('path');

const htmlPath = process.argv[2] || path.join(__dirname,'dist','formulation_app_PROD.html');
if (!fs.existsSync(htmlPath)){ console.error('File not found:', htmlPath); process.exit(1); }

const html = fs.readFileSync(htmlPath, 'utf8');

// Split into CDN script, app script, and non-script HTML
// The app has 2 script tags: 1 CDN (supabase-js) + 1 app IIFE
const scripts = [...html.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/gi)];
const cdnScript  = scripts.find(m => m[1].includes('src='));
const appScript  = scripts.find(m => !m[1].includes('src='));
const js = appScript ? appScript[2] : '';

const preHtml  = html.slice(0, html.indexOf('<script'));
const postHtml = html.slice(html.lastIndexOf('</script>') + 9);

let P = 0, F = 0;
function chk(desc, ok) {
  if (ok) { P++; process.stdout.write('  \u2713 ' + desc + '\n'); }
  else     { F++; process.stdout.write('  \u2717 FAIL: ' + desc + '\n'); }
}
function note(desc) { process.stdout.write('  \u2139 ' + desc + '\n'); }

console.log('\nVerifying: ' + path.basename(htmlPath));
console.log('\u2500'.repeat(58));

// ── HTML structure ────────────────────────────────────────────────────────────
chk('2 script tags (CDN + app)',     scripts.length === 2);
chk('CDN script is supabase-js',     cdnScript && cdnScript[1].includes('supabase-js'));
chk('App script present and large',  js.length > 100000);
chk('No content after </html>',      !html.slice(html.lastIndexOf('</html>') + 7).trim());
chk('Paywall overlay in HTML',        html.includes('paywallOverlay'));
chk('Trial banner in HTML',           html.includes('trialBanner'));
chk('Google Sign-In screen in HTML',  html.includes('googleSignInScreen'));
note('AUTH_ENABLED flag is obfuscated (correct — obfuscator renamed it to hex identifier)');
chk('Header icon in HTML',            html.includes('header-icon'));

// ── Obfuscation effectiveness ─────────────────────────────────────────────────
chk('computeRecipe() not readable',    !js.includes('computeRecipe'));
chk('var PRODUCTS not readable',       !js.includes('var PRODUCTS'));
chk('var PRICE_RULES not readable',    !js.includes('var PRICE_RULES'));
chk('Titanium dioxide not readable',   !js.includes('Titanium dioxide'));
chk('formulation sheet not readable',  !js.includes('formulation sheet covers'));
chk('SUPABASE_KEY not readable',       !js.includes('SUPABASE_KEY'));

// ── Window globals present (as obfuscated property assignments) ───────────────
chk('window globals pattern present',
  (js.match(/window\./g)||[]).length >= 3 ||
  (js.match(/window\[/g)||[]).length >= 5);
note('window.printFormulation/etc are obfuscated to window[_0x...] — still functional');

// ── File size sanity ──────────────────────────────────────────────────────────
const kb = Buffer.byteLength(html, 'utf8') / 1024;
chk('Output > 400 KB (content present)',  kb > 400);
chk('Output < 1800 KB (not exploded)',     kb < 1800);
console.log('\n  File size: ' + Math.round(kb) + ' KB');
console.log('  JS size  : ' + Math.round(js.length / 1024) + ' KB');
console.log('  Obfuscated string array calls: ' +
  ((js.match(/\b_0x[a-f0-9]+\(/g)||[]).length).toLocaleString());

console.log('\n' + '\u2500'.repeat(58));
const verdict = F === 0
  ? '\u2705 BUILD VERIFIED \u2014 READY FOR PACKAGING'
  : '\u274C ' + F + ' check(s) failed \u2014 DO NOT SHIP';
console.log('  ' + verdict);
console.log('  ' + P + ' passed  |  ' + F + ' failed');
console.log('\u2500'.repeat(58) + '\n');
process.exit(F > 0 ? 1 : 0);
