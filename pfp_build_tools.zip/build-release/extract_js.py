#!/usr/bin/env python3
"""
extract_js.py
Extracts the <script> block from the HTML source file.
Usage: python3 extract_js.py <input.html> <output.js>
The original HTML file is NEVER modified.
"""
import sys, re

def extract(html_path, js_path):
    with open(html_path, 'r', encoding='utf-8') as f:
        html = f.read()

    # Find the single app script block (the one containing the IIFE)
    start_tag = '<script>'
    end_tag   = '</script>'
    si = html.find(start_tag)
    ei = html.rfind(end_tag)
    if si < 0 or ei < 0:
        print("ERROR: Could not locate <script> block", file=sys.stderr)
        sys.exit(1)

    js = html[si + len(start_tag):ei]
    with open(js_path, 'w', encoding='utf-8') as f:
        f.write(js)

    print(f"Extracted {len(js):,} chars → {js_path}")

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("Usage: python3 extract_js.py <input.html> <output.js>")
        sys.exit(1)
    extract(sys.argv[1], sys.argv[2])
