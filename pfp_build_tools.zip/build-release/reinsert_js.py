#!/usr/bin/env python3
"""
reinsert_js.py
Replaces the <script> block in the HTML template with the processed JS.
Writes to a NEW file — the original HTML is NEVER touched.
Usage: python3 reinsert_js.py <source.html> <processed.js> <output.html>
"""
import sys, os

def reinsert(html_path, js_path, out_path):
    with open(html_path, 'r', encoding='utf-8') as f:
        html = f.read()
    with open(js_path, 'r', encoding='utf-8') as f:
        new_js = f.read()

    start_tag = '<script>'
    end_tag   = '</script>'
    si = html.find(start_tag)
    ei = html.rfind(end_tag)
    if si < 0 or ei < 0:
        print("ERROR: Could not locate <script> block", file=sys.stderr)
        sys.exit(1)

    result = html[:si + len(start_tag)] + '\n' + new_js + '\n' + html[ei:]

    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(result)

    orig_kb = len(html)     // 1024
    new_kb  = len(result)   // 1024
    js_kb   = len(new_js)   // 1024
    print(f"Source HTML : {orig_kb} KB")
    print(f"Processed JS: {js_kb} KB")
    print(f"Output HTML : {new_kb} KB  →  {out_path}")

if __name__ == '__main__':
    if len(sys.argv) != 4:
        print("Usage: python3 reinsert_js.py <source.html> <processed.js> <output.html>")
        sys.exit(1)
    reinsert(sys.argv[1], sys.argv[2], sys.argv[3])
