# Nextritech PFP — Production Build Tools

## Overview

These tools minify and obfuscate `formulation_app.html` for release.
**The original file is never touched.** You always edit `formulation_app.html`
directly; run this pipeline only when preparing a Play Store release.

## How it works

```
formulation_app.html  (your working file — never modified)
        │
        ▼
  extract_js.py      ← pulls the <script> block out
        │
        ▼
    Terser           ← minifies: removes whitespace, drops console.log,
        │               renames internal vars to short names
        ▼
  javascript-        ← obfuscates: encrypts strings, flattens control
  obfuscator           flow, injects dead code, enables self-defence
        │
        ▼
  reinsert_js.py     ← puts processed JS back into a copy of the HTML
        │
        ▼
dist/formulation_app_PROD.html  ← ship this to Capacitor/Play Store
        │
        ▼
  verify_release.js  ← confirms obfuscation worked and app structure
                        is intact before you package
```

## First-time setup

```bash
cd build-release/
npm install
```

## Running a release build

```bash
bash build_release.sh
# or with explicit path:
bash build_release.sh /path/to/formulation_app.html
```

The script will:
1. Extract the JS (~350 KB raw)
2. Minify (~170 KB) — ~50% reduction
3. Obfuscate (~250 KB) — strings encrypted, logic scrambled
4. Produce `dist/formulation_app_PROD.html`
5. Run verification checks
6. Clean up intermediate files

## Capacitor integration

Copy `dist/formulation_app_PROD.html` to your Capacitor `www/` folder
as `index.html` before running `npx cap copy android`.

```bash
bash build_release.sh
cp dist/formulation_app_PROD.html ../capacitor-project/www/index.html
cd ../capacitor-project
npx cap copy android
# then build signed AAB in Android Studio
```

## What the obfuscator protects

| Your IP | Before obfuscation | After obfuscation |
|---|---|---|
| Formulation algorithms | `computeRecipe()` — readable | `_0x3a7f()` — scrambled |
| Product formulas | `PRODUCTS = { membrane: {...` | Encrypted string array |
| PRICE_RULES | `['titanium dioxide', 3.75]` | Unreadable |
| Storage keys | `'pfp_install_ts'` | Encrypted |
| Phase methods | Full English paragraphs | Encrypted |

## What is NOT protected (and doesn't need to be)

- CSS styling
- HTML structure
- Language strings (obfuscated but reconstructible — low value anyway)
- The paywall UI (competitors can see your pricing; that's fine)

## Verify-only (without rebuilding)

```bash
node verify_release.js dist/formulation_app_PROD.html
```

## Important notes

- Never use the PROD file for development — self-defending code
  will detect reformatting and stop working
- Store your signing keystore safely — it cannot be recovered
- The Supabase credentials (`SUPABASE_URL`, `SUPABASE_KEY`) should
  be injected at build time, not hardcoded — see main roadmap doc
- Run a full build before every Play Store release, not just on
  feature changes
