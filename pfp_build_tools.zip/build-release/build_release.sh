#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
# build_release.sh
# Nextritech Paint Formulation Studio Pro — Production Build Pipeline
#
# What this does:
#   1. Extracts JS from the UNMODIFIED source HTML
#   2. Minifies with Terser (whitespace, dead code, short variable names)
#   3. Obfuscates with javascript-obfuscator (string encryption, control-flow
#      flattening, self-defending code)
#   4. Reinserts processed JS into a NEW HTML file in dist/
#   5. Runs verify_release.js to confirm the build is valid
#
# The original formulation_app.html is NEVER modified.
# Edit that file as normal; run this script when you want a release build.
#
# Usage:
#   bash build_release.sh [path/to/formulation_app.html]
#
# Requirements:
#   npm install  (runs terser and javascript-obfuscator from node_modules)
#   python3
# ═══════════════════════════════════════════════════════════════════════════════

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_HTML="${1:-$(dirname "$SCRIPT_DIR")/formulation_app.html}"
DIST_DIR="$SCRIPT_DIR/dist"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# Output paths — all in dist/, never touching the source
RAW_JS="$DIST_DIR/raw_$TIMESTAMP.js"
MINIFIED_JS="$DIST_DIR/minified_$TIMESTAMP.js"
OBFUSCATED_JS="$DIST_DIR/obfuscated_$TIMESTAMP.js"
OUTPUT_HTML="$DIST_DIR/formulation_app_PROD.html"
LATEST_HTML="$DIST_DIR/formulation_app_PROD_latest.html"

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  Nextritech PFP — Production Build Pipeline              ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "  Source : $SOURCE_HTML"
echo "  Output : $OUTPUT_HTML"
echo "  Time   : $TIMESTAMP"
echo ""

# ── Preflight ──────────────────────────────────────────────────────────────────
if [ ! -f "$SOURCE_HTML" ]; then
  echo "ERROR: Source file not found: $SOURCE_HTML"
  exit 1
fi

if [ ! -d "$SCRIPT_DIR/node_modules" ]; then
  echo "Installing build dependencies..."
  cd "$SCRIPT_DIR" && npm install --silent
fi

mkdir -p "$DIST_DIR"

TERSER="$SCRIPT_DIR/node_modules/.bin/terser"
OBFUSCATOR="$SCRIPT_DIR/node_modules/.bin/javascript-obfuscator"

# ── Step 1: Extract JS ─────────────────────────────────────────────────────────
echo "Step 1/4  Extracting JS from source HTML..."
python3 "$SCRIPT_DIR/extract_js.py" "$SOURCE_HTML" "$RAW_JS"

RAW_SIZE=$(wc -c < "$RAW_JS")
echo "          Raw JS: $(echo "$RAW_SIZE / 1024" | bc) KB"
echo ""

# ── Step 2: Minify with Terser ─────────────────────────────────────────────────
echo "Step 2/4  Minifying with Terser..."
"$TERSER" "$RAW_JS" \
  --compress \
    "drop_console=true,\
passes=3,\
dead_code=true,\
drop_debugger=true,\
pure_funcs=['console.log','console.warn','console.info']" \
  --mangle \
    "reserved=['window','document','localStorage','JSON','Date',\
'Math','Promise','fetch','alert','confirm','prompt',\
'setTimeout','clearTimeout','setInterval',\
'printFormulation','printOrderPlan','showPaywall','hidePaywall',\
'handlePurchase','restorePurchases','dispatchFinishedGoods']" \
  --output "$MINIFIED_JS"

MIN_SIZE=$(wc -c < "$MINIFIED_JS")
REDUCTION=$(( (RAW_SIZE - MIN_SIZE) * 100 / RAW_SIZE ))
echo "          Minified: $(echo "$MIN_SIZE / 1024" | bc) KB  (${REDUCTION}% reduction)"
echo ""

# ── Step 3: Obfuscate with javascript-obfuscator ──────────────────────────────
echo "Step 3/4  Obfuscating (this takes 20–40 seconds)..."
"$OBFUSCATOR" "$MINIFIED_JS" \
  --output "$OBFUSCATED_JS" \
  --compact true \
  --control-flow-flattening true \
  --control-flow-flattening-threshold 0.5 \
  --dead-code-injection true \
  --dead-code-injection-threshold 0.2 \
  --identifier-names-generator hexadecimal \
  --rename-globals false \
  --string-array true \
  --string-array-encoding base64 \
  --string-array-threshold 0.8 \
  --string-array-rotate true \
  --string-array-shuffle true \
  --string-array-index-shift true \
  --self-defending true \
  --unicode-escape-sequence false \
  --reserved-names "printFormulation,printOrderPlan,showPaywall,hidePaywall,handlePurchase,restorePurchases,dispatchFinishedGoods"

OBF_SIZE=$(wc -c < "$OBFUSCATED_JS")
echo "          Obfuscated: $(echo "$OBF_SIZE / 1024" | bc) KB"
echo ""

# ── Step 4: Reinsert into HTML ────────────────────────────────────────────────
echo "Step 4/4  Reinserting into HTML..."
python3 "$SCRIPT_DIR/reinsert_js.py" "$SOURCE_HTML" "$OBFUSCATED_JS" "$OUTPUT_HTML"

# Also write a stable "latest" symlink for Capacitor to always reference
cp "$OUTPUT_HTML" "$LATEST_HTML"
echo ""

# ── Verify ────────────────────────────────────────────────────────────────────
echo "Verifying build..."
node "$SCRIPT_DIR/verify_release.js" "$OUTPUT_HTML"

# ── Cleanup intermediate files ────────────────────────────────────────────────
rm -f "$RAW_JS" "$MINIFIED_JS" "$OBFUSCATED_JS"
echo "  Intermediate files cleaned up."
echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  BUILD COMPLETE                                          ║"
echo "║  Production file: dist/formulation_app_PROD.html        ║"
echo "║  Copy this file to your Capacitor www/ folder           ║"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
